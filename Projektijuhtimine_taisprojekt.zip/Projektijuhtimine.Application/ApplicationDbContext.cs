using Microsoft.EntityFrameworkCore;
using Projektijuhtimine.Application.Data;

namespace Projektijuhtimine.Application;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Project> Projects => Set<Project>();
    public DbSet<ProjectMember> ProjectMembers => Set<ProjectMember>();
    public DbSet<Data.Task> Tasks => Set<Data.Task>();
    public DbSet<WorkLog> WorkLogs => Set<WorkLog>();
    public DbSet<Attachment> Attachments => Set<Attachment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<User>().HasIndex(x => x.Username).IsUnique();
        modelBuilder.Entity<User>().HasIndex(x => x.Email).IsUnique();
        modelBuilder.Entity<ProjectMember>().HasIndex(x => new { x.ProjectId, x.UserId }).IsUnique();

        modelBuilder.Entity<Data.Task>()
            .HasOne(x => x.ResponsibleUser)
            .WithMany(x => x.ResponsibleTasks)
            .HasForeignKey(x => x.ResponsibleUserId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
