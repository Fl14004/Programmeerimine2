using Microsoft.EntityFrameworkCore;
using Projektijuhtimine.Application.Data;

namespace Projektijuhtimine.Application;

/// <summary>Creates realistic demo data. Every main table receives at least 35 rows.</summary>
public static class SeedData
{
    public static async System.Threading.Tasks.Task InitializeAsync(ApplicationDbContext db)
    {
        await db.Database.MigrateAsync();

        // Do not duplicate demo data when the database already contains users.
        if (await db.Users.AnyAsync()) return;

        var firstNames = new[] { "Mari", "Jaan", "Kati", "Martin", "Laura", "Rasmus", "Anna", "Karl", "Liis", "Markus" };
        var lastNames = new[] { "Tamm", "Saar", "Sepp", "Mägi", "Kask", "Rebane", "Kukk", "Ilves", "Pärn", "Oja" };
        var users = Enumerable.Range(1, 35).Select(i => new User
        {
            Username = $"{firstNames[(i - 1) % firstNames.Length].ToLowerInvariant()}{i}",
            Email = $"kasutaja{i}@example.com",
            // Demo-only placeholder; never store plain-text passwords in a real application.
            Password = $"DEMO-ONLY-CHANGE-ME-{i}"
        }).ToList();
        db.Users.AddRange(users);

        var projects = Enumerable.Range(1, 35).Select(i => new Project
        {
            Name = new[] { "Veebilehe uuendus", "Kliendiportaal", "Andmebaasi korrastus", "Mobiilirakendus", "Siseveebi arendus" }[(i - 1) % 5] + $" {i}",
            StartDate = new DateTime(2026, 1, 1).AddDays(i * 2),
            Deadline = new DateTime(2026, 1, 1).AddDays(i * 2 + 45),
            Budget = 2500m + i * 375m,
            HourlyRate = 25m + (i % 5) * 5m
        }).ToList();
        db.Projects.AddRange(projects);
        await db.SaveChangesAsync();

        var members = Enumerable.Range(1, 35).Select(i => new ProjectMember
        {
            ProjectId = projects[i - 1].Id,
            UserId = users[i - 1].Id
        }).ToList();
        // Add extra membership links to make the many-to-many relationship visible.
        members.AddRange(Enumerable.Range(0, 35).Select(i => new ProjectMember
        {
            ProjectId = projects[i].Id,
            UserId = users[(i + 1) % users.Count].Id
        }));
        db.ProjectMembers.AddRange(members);

        var taskTitles = new[] { "Nõuete kogumine", "Kasutajaliidese kavandamine", "Andmebaasi loomine", "API arendamine", "Testimine", "Dokumentatsiooni koostamine", "Paranduste tegemine" };
        var tasks = Enumerable.Range(1, 70).Select(i => new Data.Task
        {
            ProjectId = projects[(i - 1) % projects.Count].Id,
            Title = taskTitles[(i - 1) % taskTitles.Length] + $" #{i}",
            StartDate = new DateTime(2026, 2, 1).AddDays(i),
            EstimatedHours = 2 + (i % 8) * 1.5m,
            FixedPrice = i % 10 == 0 ? 150m + i * 5m : null,
            ResponsibleUserId = users[(i - 1) % users.Count].Id,
            Description = $"Ülesande {i} töö kirjeldus: teostada, kontrollida ja dokumenteerida vajalikud muudatused.",
            IsCompleted = i % 4 == 0
        }).ToList();
        db.Tasks.AddRange(tasks);
        await db.SaveChangesAsync();

        var workLogs = Enumerable.Range(1, 70).Select(i => new WorkLog
        {
            TaskId = tasks[i - 1].Id,
            Date = new DateTime(2026, 3, 1).AddDays(i),
            Hours = 1 + (i % 6) * 0.5m,
            UserId = users[(i - 1) % users.Count].Id,
            Description = new[] { "Arendustöö", "Koosolek ja täpsustused", "Testimine", "Koodi ülevaatus", "Dokumenteerimine" }[(i - 1) % 5]
        }).ToList();
        db.WorkLogs.AddRange(workLogs);

        var attachments = Enumerable.Range(1, 35).Select(i => new Attachment
        {
            TaskId = tasks[(i - 1) % tasks.Count].Id,
            FileName = $"projekti-dokument-{i:D2}.pdf",
            FilePath = $"uploads/demo/projekti-dokument-{i:D2}.pdf",
            UploadedAt = new DateTime(2026, 4, 1).AddDays(i),
            UserId = users[(i - 1) % users.Count].Id
        }).ToList();
        db.Attachments.AddRange(attachments);
        await db.SaveChangesAsync();
    }
}
