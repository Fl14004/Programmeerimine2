# Projektijuhtimine

Projektijuhtimise tööde haldamise ja monitoorimise süsteemi klassiskeem.

## Failid

- `Projektijuhtimine_klassiskeem.drawio` – diagrams.net XML-formaadis klassiskeem
- `Projektijuhtimine_klassiskeem.png` – klassiskeemi PNG-versioon
- `Klasside_dokumentatsioon.docx` – klasside dokumentatsioon
- `Klasside_dokumentatsioon.md` – sama dokumentatsioon Markdown-formaadis

## Märkus

Õpetaja antud `InvoiceModel.docx` tuleb lisada sellesse kausta eraldi, sest seda faili ei ole selles vestluses üles laaditud.
