# Projektijuhtimine – valmis Application/Data klassid

See kaust sisaldab projektijuhtimise süsteemi klassid vastavalt klassiskeemile.

## Klassid

- User
- Project
- ProjectMember
- Task
- WorkLog
- Attachment

## DataAnnotations

Kasutatud on ainult andmete reeglite kirjeldamiseks vajalikke atribuute:

- Required
- StringLength
- EmailAddress
- Range

## Visual Studio

Kopeeri kaust `Projektijuhtimine.Application/Data` enda olemasoleva Application projekti `Data` kausta.

Kontrolli seejärel namespace'i, kui sinu olemasolevas projektis kasutatakse teistsugust namespace'i.

Pärast kopeerimist:

1. Ava lahendus Visual Studios.
2. Build → Build Solution.
3. Kontrolli, et build õnnestub.
4. Git add/commit/push, et muudatused GitHubi jõuaksid.
