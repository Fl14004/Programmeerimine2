using System.ComponentModel.DataAnnotations;

namespace Projektijuhtimine.Application.Data;

public class Task
{
    public int Id { get; set; }

    [Required]
    public int ProjectId { get; set; }

    [Required]
    [StringLength(200)]
    public string Title { get; set; } = string.Empty;

    [Required]
    public DateTime StartDate { get; set; }

    [Required]
    [Range(0, 1000000)]
    public decimal EstimatedHours { get; set; }

    [Range(0, 1000000000)]
    public decimal? FixedPrice { get; set; }

    [Required]
    public int ResponsibleUserId { get; set; }

    [StringLength(5000)]
    public string? Description { get; set; }

    [Required]
    public bool IsCompleted { get; set; }

    public Project? Project { get; set; }
    public User? ResponsibleUser { get; set; }
    public ICollection<WorkLog> WorkLogs { get; set; } = new List<WorkLog>();
    public ICollection<Attachment> Attachments { get; set; } = new List<Attachment>();
}
