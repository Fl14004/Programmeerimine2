using System.ComponentModel.DataAnnotations;

namespace Projektijuhtimine.Application.Data;

public class Project
{
    public int Id { get; set; }

    [Required]
    [StringLength(200)]
    public string Name { get; set; } = string.Empty;

    [Required]
    public DateTime StartDate { get; set; }

    [Required]
    public DateTime Deadline { get; set; }

    [Required]
    [Range(0, 1000000000)]
    public decimal Budget { get; set; }

    [Required]
    [Range(0, 1000000)]
    public decimal HourlyRate { get; set; }

    public ICollection<ProjectMember> ProjectMembers { get; set; } = new List<ProjectMember>();
    public ICollection<Task> Tasks { get; set; } = new List<Task>();
}
