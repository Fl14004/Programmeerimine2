using System.ComponentModel.DataAnnotations;

namespace Projektijuhtimine.Application.Data;

public class ProjectMember
{
    public int Id { get; set; }

    [Required]
    public int ProjectId { get; set; }

    [Required]
    public int UserId { get; set; }

    public Project? Project { get; set; }
    public User? User { get; set; }
}
