using System.ComponentModel.DataAnnotations;

namespace Projektijuhtimine.Application.Data;

public class WorkLog
{
    public int Id { get; set; }

    [Required]
    public int TaskId { get; set; }

    [Required]
    public DateTime Date { get; set; }

    [Required]
    [Range(0, 1000000)]
    public decimal Hours { get; set; }

    [Required]
    public int UserId { get; set; }

    [StringLength(5000)]
    public string? Description { get; set; }

    public Task? Task { get; set; }
    public User? User { get; set; }
}
